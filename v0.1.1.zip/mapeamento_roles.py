# Defina todos os mapeamentos aqui
mapeamento_roles = {
    # home
    'principal': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    
    # gerenciar
    'projetos_listar': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral'],
    'projeto_detalhes': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral'],
    'projeto_cadastrar': ['root', 'usuario_master'],
    'projeto_editar': ['root', 'usuario_master'],
    'projeto_ativar': ['root', 'usuario_master'],
    'projeto_desativar': ['root', 'usuario_master'],
    'atividade_download_anexo': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    'atividades_listar': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    'atividade_visualizar': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    'atividade_cadastrar': ['root', 'usuario_master'],
    'atividade_editar': ['root', 'usuario_master'],
    'atividade_remover_anexo': ['root', 'usuario_master'],
    'atividade_excluir': ['root', 'usuario_master'],
    'atividade_duplicar': ['root', 'usuario_master'],
    'lancamento_horas_listar': ['root', 'usuario_master'],
    'lancamento_horas_editar': ['root', 'usuario_master'],
    'lancamento_horas_cadastrar': ['root', 'usuario_master'],
    'lancamento_horas_excluir': ['root', 'usuario_master'],
    'obter_atividades_por_projeto': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    'kanban_visualizar': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    'kanban_atualizar_prioridade': ['root', 'usuario_master'],
    'kanban_atualizar_situacao': ['root', 'usuario_master'],
    'kanban_filtrar': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    'kanban_detalhes_atividade': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo', 'auxiliar_geral', 'analista'],
    
    # usuario
    'usuarios_listar': ['root', 'usuario_master'],
    'usuario_cadastrar': ['root', 'usuario_master'],
    'usuario_editar': ['root', 'usuario_master'],
    'usuario_excluir': ['root', 'usuario_master'],
    'usuario_ativar': ['root', 'usuario_master'],
    'usuario_desativar': ['root', 'usuario_master'],
    'usuario_reenvio_email': ['root', 'usuario_master'],
    'usuario_minha_conta': ['root', 'usuario_master', 'gerente','financeiro', 'administrativo', 'auxiliar_geral', 'analista'],

    # Movimentação financeira
    'movimentacao_financeira': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'lancamentos_financeiros': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'cadastrar_lancamento': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'editar_lancamento': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'excluir_lancamento': ['root', 'usuario_master', 'gerente', 'financeiro'],

    'listar_plano_contas': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'criar_subcategoria': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'editar_categoria': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'excluir_categoria': ['root', 'usuario_master', 'gerente', 'financeiro'],
    'api_estrutura_plano_contas': ['root', 'usuario_master', 'gerente'],
    'listar_categorias_inativas': ['root', 'usuario_master', 'gerente'],
    'reativar_categoria': ['root', 'usuario_master', 'gerente'],
    'permitir_alterar_estrutura': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo'],
    'negar_alterar_estrutura': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo'],


    # DRE
    'demonstrativo_de_resultados': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo'],
    'dre_pdf': ['root', 'usuario_master', 'gerente', 'financeiro', 'administrativo'],

    # Recebimento
    'lancamentos_receber': ['root', 'usuario_master', 'gerente'],
    'informar_recebimento': ['root', 'usuario_master', 'gerente'],
    'cancelar_informe_recebimento': ['root', 'usuario_master', 'gerente'],

    # Gerenciar
    'cadastrar_cliente': ['root', 'usuario_master', 'gerente'],
    'listar_clientes': ['root', 'usuario_master', 'gerente'],
    'editar_cliente': ['root', 'usuario_master', 'gerente'],
    'desativar_cliente': ['root', 'usuario_master', 'gerente'],
    'ativar_cliente': ['root', 'usuario_master', 'gerente'],
    'obter_produto': ['root', 'usuario_master', 'gerente'],
    'cadastrar_produto': ['root', 'usuario_master', 'gerente'],
    'editar_produto': ['root', 'usuario_master', 'gerente'],
    'listar_produtos': ['root', 'usuario_master', 'gerente'],
    'ativar_produto': ['root', 'usuario_master', 'gerente'],
    'desativar_produto': ['root', 'usuario_master', 'gerente'],

    'contrato_cadastrar': ['root', 'usuario_master', 'gerente'],
    'contrato_listar': ['root', 'usuario_master', 'gerente'],
    'contrato_editar': ['root', 'usuario_master', 'gerente'],
    'contrato_excluir': ['root', 'usuario_master', 'gerente'],
    'cadastrar_contrato_assinado': ['root', 'usuario_master', 'gerente'],
    'contrato_exportar_pdf': ['root', 'usuario_master', 'gerente'],

    # Relatórios
    'exportar_relatorio_horas_dev': ['root', 'usuario_master', 'gerente'],
    'exportar_movimentacao_financeira': ['root', 'usuario_master', 'gerente'],

    # configurações
    'andamentos_listar': ['root', 'usuario_master'],
    'andamento_cadastrar': ['root', 'usuario_master'],
    'andamento_editar': ['root', 'usuario_master'],
    'andamento_excluir': ['root', 'usuario_master'],
    'andamento_ativar': ['root', 'usuario_master'],
    'andamento_desativar': ['root', 'usuario_master'],
    'andamentos_atividade_listar': ['root', 'usuario_master'],
    'andamento_atividade_cadastrar': ['root', 'usuario_master'],
    'andamento_atividade_editar': ['root', 'usuario_master'],
    'andamento_atividade_excluir': ['root', 'usuario_master'],
    'andamento_atividade_ativar': ['root', 'usuario_master'],
    'andamento_atividade_desativar': ['root', 'usuario_master'],
    'prioridades_atividade_listar': ['root', 'usuario_master'],
    'prioridade_atividade_cadastrar': ['root', 'usuario_master'],
    'prioridade_atividade_editar': ['root', 'usuario_master'],
    'prioridade_atividade_excluir': ['root', 'usuario_master'],
    'prioridade_atividade_ativar': ['root', 'usuario_master'],
    'prioridade_atividade_desativar': ['root', 'usuario_master'],
    'roles_listar': ['root', 'usuario_master'],
    'role_cadastrar': ['root', 'usuario_master'],
    'role_editar': ['root', 'usuario_master'],
    'role_excluir': ['root', 'usuario_master'],
    'variaveis_sistema_editar': ['root', 'usuario_master'],
    'changelog_listar': ['root', 'usuario_master', 'gerente'],
    'changelog_cadastrar': ['root'],
    'changelog_editar': ['root'],

    # Tags (Configurações)
    'tags_listar': ['root'],
    'tags_cadastrar': ['root'],
    'tags_tabela': ['root'],
    'tags_editar': ['root'],
    'tags_deletar': ['root'],

    # Configurações contrato
    'cadastrar_modelo_contrato': ['root', 'usuario_master'],
    'listar_modelos_contratos': ['root', 'usuario_master'],
    'editar_modelo_contrato': ['root', 'usuario_master'],
    'excluir_modelo_contrato': ['root', 'usuario_master'],
}
